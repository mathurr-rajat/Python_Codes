from class_static_method import Demo

object1 = Demo()

# change value by instance method
# it will be accessible by instance method
object1.change_value()
object1.show_instance()

# change value by instance method
# it not affects class variable
# value change by instance method is confined to that scope only
object1.change_value()
object1.show_class()

# change value by instance method
# it not affects static variable because static method is not able
# to access class or instances variables,static method only can access those variables which
# is provided to it
object1.change_value()
object1.show_static(134)
