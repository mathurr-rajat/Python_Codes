from class_static_method import Demo

object1 = Demo()
# instance method can not be access by class name
# you have to create object
object1.show_instance()

# class,static method can be access by class name
Demo.show_static(7)
Demo.show_class()
