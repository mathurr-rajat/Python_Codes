class Product:
    count = 0

    def __init__(self, name):
        self.name = name
        Product.count = Product.count + 1

    def display_data(self):
        Product.count = Product.count + 1
        print(f"name is {self.name}")
        print(f"count = {Product.count}")


prod_object = Product("camera")
prod_object.display_data()
prod_object.display_data()
prod_object.display_data()