# access of class variable in instance method, class method and static method

# class variable can be access by class,instances method
# class variable can not access by static method

class Demo:
    price = 0

    def __init__(self):
        pass

    @classmethod
    def show_class(cls):
        cls.price = 150
        print(cls.price)

    # instances method
    def show_instance(self):
        # price is class variable, but it can be access here
        # if anywhere you change class variable, it will impact at all
        # the instances
        print(self.price)

    """
    static method is bound to class rather that objects of class
    it doesn't require cls or self
    static method can't access instances attribute
    static method can access class variables with class name
    """

    @staticmethod
    def show_static(a):
        print(a)
        # price is class variable, but it can not access here
        # it will give error
        # print(price)

    def change_value(self):
        self.price = 900

# object1 = Demo()
# object1.show()
# Demo.show()
# object1.show_instance()
# object1.show_static(9)
