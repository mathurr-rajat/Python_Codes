"""
    static method is bound to class rather that objects of class
    it doesn't require cls or self
    static method can't access instances attribute
    static method can access class variables with class name
"""

class Math1:
    length = 10

    def __init__(self, b):
        self.b = b

    @staticmethod
    def display():
        # static method can access class variables with class name
        print(f"length = {Math1.length}")
        # this line will give error because static method can not access instance variables
        # print(f"{self.b}")


object1 = Math1(20)

object1.display()
