# program just shows that class method can return object

class Demo:
    def __init__(self, item, price):
        self.item = item
        self.price = price

    def display(self):
        print(f"item is {self.item} price is {self.price}")


    @classmethod
    def return_object(cls, item, price):
        return Demo(item, price)


Demo_object = Demo("pizza", 500)
Demo_object.display()

# P2 = Demo.return_object("Berger", 390)
Demo.return_object("Berger", 390)
# P2.display()
Demo("Berger", 390).display()