import chart_studio

def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(a, b):
    return a * b


def divide(a, b):
    return a / b


def even_numbers():
    even_list = []
    for number in range(1, 10):
        # print(number)
        # print(even_list)
        if number % 2 == 0:
            even_list.append(number)
    return even_list


# def check_input(unit_id, si_unit):
#     if unit_id and si_unit is not [None,'']:
#         print("valid input")
#     elif unit_id is not [None,''] and

def and_gate(a, b):
    return a * b
