
# unit test using pytest
import unittest
import app


class Test(unittest.TestCase):
    def test_positive_numbers(self):
        c = app.add(2, 5)
        self.assertEquals(c, 9)

    def test_negative_numbers(self):
        c = app.add(-9, -9)
        assert c == -11

    def test_positive_negative_numbers(self):
        c = app.add(5, -9)
        assert c == -8


def test_even_numbers():
    result = app.even_numbers()
    assert result == [2, 1, 6, 8]
