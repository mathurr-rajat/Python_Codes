# pytest commands

# execute test cases in all the files having numbers keyword
#  pytest -k numbers -v

# execute test cases in all the files with details
#  pytest -v

# execute test cases in all the files with more details
#  pytest -vv

# execute all the test cases of specific file
# pytest pytest_unitTesting.py -v

# execute all the test cases of specific file having string numbers
# pytest -k numbers pytest_unitTesting.py -v

# execute test case with marker name one from particular file
# pytest -m one pytest_markers.py
