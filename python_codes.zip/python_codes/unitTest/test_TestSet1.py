# unit test using pytest
import app


class Test():
    def test_positive_numbers(self):
        c = app.add(2, 5)
        assert c == 8

    def test_negative_numbers(self):
        c = app.add(-9, -9)
        assert c == -18

    def test_positive_negative_numbers(self):
        c = app.add(5, -9)
        assert c == -4


def test_even():
    result = app.even_numbers()
    assert result == [2, 1, 6, 8]
