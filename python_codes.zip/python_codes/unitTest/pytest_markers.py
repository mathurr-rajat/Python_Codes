import pytest
import app


@pytest.mark.zero
def test_and_gate():
    c = app.and_gate(0, 0)
    assert c == 0


@pytest.mark.zero
def test_and_gate():
    c = app.and_gate(0, 1)
    assert c == 0


@pytest.mark.one
def test_and_gate():
    c = app.and_gate(1, 1)
    assert c == 0
