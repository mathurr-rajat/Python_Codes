import app
import pytest


@pytest.fixture()
def input_value():
    a = 10
    return a


def test_operation1(input_value):
    assert input_value % 5 == 0


def test_operation2(input_value):
    assert input_value * 10 == 90

